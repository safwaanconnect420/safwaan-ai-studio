from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from routers import appbuilders, devtools, imagegen, videogen, llms, sketchto3d, model_manager

app = FastAPI(title="Safwaan AI Studio API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register routers
app.include_router(appbuilders.router, prefix="/appbuilders")
app.include_router(devtools.router, prefix="/devtools")
app.include_router(imagegen.router, prefix="/imagegen")
app.include_router(videogen.router, prefix="/videogen")
app.include_router(llms.router, prefix="/llms")
app.include_router(sketchto3d.router, prefix="/sketchto3d")
app.include_router(model_manager.router, prefix="/model-manager")

@app.get("/healthz")
def health_check():
    return {"status": "ok"}