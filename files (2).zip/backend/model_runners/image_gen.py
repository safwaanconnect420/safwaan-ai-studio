def generate_image(prompt: str, model_name: str = "stable-diffusion"):
    # TODO: Integrate with actual model code (API, subprocess, etc.)
    return {"image_url": "/static/generated_image.png", "model": model_name, "prompt": prompt}