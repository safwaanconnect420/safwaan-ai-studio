def generate_video(prompt: str, model_name: str = "stable-video-diffusion"):
    # TODO: Integrate with actual model code
    return {"video_url": "/static/generated_video.mp4", "model": model_name, "prompt": prompt}