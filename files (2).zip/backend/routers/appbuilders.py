from fastapi import APIRouter

router = APIRouter()

@router.get("/")
async def list_app_builders():
    return [
        {"name": "Pythagora", "url": "https://pythagora.io"},
        {"name": "Reflex", "url": "https://reflex.dev"},
        {"name": "Dropbase", "url": "https://dropbase.io"},
        {"name": "Retool", "url": "https://retool.com"},
        {"name": "UI Bakery", "url": "https://uibakery.io"},
        {"name": "Glide", "url": "https://www.glideapps.com/"},
        {"name": "Bubble", "url": "https://bubble.io/"},
    ]