from fastapi import APIRouter, Body
from model_runners.image_gen import generate_image

router = APIRouter()

@router.post("/generate")
async def image_generate(prompt: str = Body(...), model: str = Body("stable-diffusion")):
    return generate_image(prompt, model)