from fastapi import APIRouter, Body
from model_runners.llm_runner import run_llm

router = APIRouter()

@router.post("/run")
async def llm_run(prompt: str = Body(...), model: str = Body("qwen3")):
    return run_llm(prompt, model)