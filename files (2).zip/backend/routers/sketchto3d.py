from fastapi import APIRouter, UploadFile, File, Form
from model_runners.sketch_to_3d import convert_sketch_to_3d

router = APIRouter()

@router.post("/convert")
async def sketch_to_3d(file: UploadFile = File(...), model: str = Form("controlnet")):
    # Save uploaded sketch, then convert
    sketch_path = f"/tmp/{file.filename}"
    with open(sketch_path, "wb") as f:
        f.write(await file.read())
    return convert_sketch_to_3d(sketch_path, model)