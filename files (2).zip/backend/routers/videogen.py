from fastapi import APIRouter, Body
from model_runners.video_gen import generate_video

router = APIRouter()

@router.post("/generate")
async def video_generate(prompt: str = Body(...), model: str = Body("stable-video-diffusion")):
    return generate_video(prompt, model)