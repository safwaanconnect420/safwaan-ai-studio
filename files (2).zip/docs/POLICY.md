# Safwaan AI Studio – Usage & Community Policy

## Usage

- Free for commercial/noncommercial use under MIT
- No unlawful, discriminatory, or malicious use
- Respect licensing of 3rd party models/tools

## Privacy

- Local-first: Your data is private unless you opt for cloud features
- Cloud: AWS or other providers govern data security
- API keys/secrets must be protected

## Responsible AI

- Users are responsible for outputs
- Validate content before production use
- Disclose bias and provenance when deploying models

## Contributing

- All code under MIT, Apache 2.0, or compatible
- Respectful, inclusive, professional conduct

## Compliance

- Follow laws in your jurisdiction
- Policy updates in repo as project grows