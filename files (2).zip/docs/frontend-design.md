# Safwaan AI Studio – Advanced Frontend Design

## UI/UX Principles

- Modular, animated, card/grid layouts (Botly/AppSmith/Dribbble/Behance inspired)
- Split view, drag-and-drop, theme switching (dark/light/accent)
- Search, breadcrumbs, notifications, accessibility focus

## Component Map

- **Sidebar.tsx**: Tab navigation, icons, tooltips, collapsible
- **Header.tsx**: App name, user profile/menu, notifications, theme switch
- **TabContent.tsx**: Loads selected panel (below)
- **AppBuildersPanel.tsx**: All builder integrations (Pythagora, Reflex, etc.)
- **DevToolsPanel.tsx**: Developer utilities (Httpie, Swagger, etc.)
- **ImageGenPanel.tsx**: Text-to-image AI models
- **VideoGenPanel.tsx**: Text/image-to-video models & workflow
- **LLMPanel.tsx**: Language, code, multimodal models (Qwen3, DeepSeek, etc.)
- **SketchTo3DPanel.tsx**: Drawing pad, model selector, 3D viewer, export
- **ModelManagerPanel.tsx**: Install, run, monitor, compare models
- **Breadcrumbs.tsx**: Navigation path
- **SearchBar.tsx**: Global quick search
- **Notification.tsx**: Toasts/alerts
- **ExportButton.tsx**: Download/export output
- **ComparisonPanel.tsx**: Compare model results
- **Footer.tsx**: Version, links, license