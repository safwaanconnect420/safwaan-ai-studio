# Safwaan AI Studio – Onboarding Guide

## Prerequisites
- Node.js 18+, Python 3.10+, Docker, Yarn (or npm)

## Local Development
- `cd frontend && yarn start`
- `cd backend && uvicorn main:app --reload`

## Deployment
- See `k8s/` for Kubernetes manifests
- See `docker-compose.yml` for local orchestration
- See `helm/` for Helm charts

## Docs
- Architecture: `docs/architecture.md`
- API Reference: Swagger UI (`/docs` endpoint on backend)