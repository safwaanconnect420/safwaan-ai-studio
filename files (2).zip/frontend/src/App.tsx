import React from "react";
import Sidebar from "./components/Sidebar";
import Header from "./components/Header";
import TabContent from "./components/TabContent";
import Footer from "./components/Footer";
import "./styles/main.css";

const tabs = [
  "App Builders",
  "Dev Tools",
  "Image Generation",
  "Video Generation",
  "LLMs",
  "Sketch to 3D",
  "Model Manager",
  "Settings"
];

export default function App() {
  const [selectedTab, setSelectedTab] = React.useState(tabs[0]);
  return (
    <div className="safwaan-ai-studio">
      <Header />
      <div className="main-layout">
        <Sidebar tabs={tabs} selected={selectedTab} onSelect={setSelectedTab} />
        <TabContent tab={selectedTab} />
      </div>
      <Footer />
    </div>
  );
}