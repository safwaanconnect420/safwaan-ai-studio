import React from "react";
const appBuilders = [
  { name: "Pythagora", url: "https://pythagora.io" },
  { name: "Reflex", url: "https://reflex.dev" },
  { name: "Dropbase", url: "https://dropbase.io" },
  { name: "Retool Community", url: "https://retool.com" },
  { name: "UI Bakery", url: "https://uibakery.io" },
  { name: "Glide", url: "https://www.glideapps.com/" },
  { name: "Bubble", url: "https://bubble.io/" },
];
export default function AppBuildersPanel() {
  return (
    <div className="panel app-builders">
      <h2>App Builders</h2>
      <div className="card-grid">
        {appBuilders.map((b) => (
          <a className="card" key={b.name} href={b.url} target="_blank" rel="noopener noreferrer">
            <span className="card-title">{b.name}</span>
            <span className="card-url">{b.url}</span>
          </a>
        ))}
      </div>
    </div>
  );
}