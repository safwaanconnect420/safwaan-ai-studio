import React from "react";
const devTools = [
  { name: "Httpie", url: "https://httpie.io/" },
  { name: "Insomnia", url: "https://insomnia.rest/" },
  { name: "Swagger UI", url: "https://swagger.io/tools/swagger-ui/" },
  { name: "Cursor", url: "https://www.cursor.so/" },
  { name: "Copilot", url: "https://github.com/features/copilot" },
  { name: "Replit", url: "https://replit.com/" },
  { name: "Pipedream OSS", url: "https://pipedream.com/open-source/" },
];
export default function DevToolsPanel() {
  return (
    <div className="panel dev-tools">
      <h2>Dev Tools</h2>
      <div className="card-grid">
        {devTools.map((t) => (
          <a className="card" key={t.name} href={t.url} target="_blank" rel="noopener noreferrer">
            <span className="card-title">{t.name}</span>
            <span className="card-url">{t.url}</span>
          </a>
        ))}
      </div>
    </div>
  );
}