import React from "react";
export default function Footer() {
  return (
    <footer className="footer">
      <span>Safwaan AI Studio &copy; 2025</span>
      <span>MIT License</span>
      <span>
        <a href="https://github.com/safwaanconnect420/safwaan-ai-studio" target="_blank" rel="noopener noreferrer">GitHub</a>
      </span>
    </footer>
  );
}