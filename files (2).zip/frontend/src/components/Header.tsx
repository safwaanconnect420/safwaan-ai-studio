import React from "react";
import { FaUserCircle, FaBell, FaSun, FaMoon } from "react-icons/fa";

export default function Header() {
  const [theme, setTheme] = React.useState("dark");
  return (
    <header className="header">
      <div className="logo">Safwaan AI Studio</div>
      <div className="header-actions">
        <button title="Notifications"><FaBell /></button>
        <button title="User"><FaUserCircle /></button>
        <button title="Toggle Theme" onClick={() => setTheme(theme === "dark" ? "light" : "dark")}>{theme === "dark" ? <FaSun /> : <FaMoon />}</button>
      </div>
    </header>
  );
}