import React from "react";
const imageModels = [
  { name: "Stable Diffusion", url: "https://github.com/CompVis/stable-diffusion" },
  { name: "Seedream-3", url: "https://github.com/ByteDance/Seedream" },
  { name: "StepStar", url: "https://github.com/StepStarAI/StepStar" },
  { name: "ComfyUI", url: "https://github.com/comfyanonymous/ComfyUI" },
  { name: "Kandinsky", url: "https://github.com/ai-forever/Kandinsky-2.2" },
];
export default function ImageGenPanel() {
  return (
    <div className="panel image-gen">
      <h2>Image Generation Models</h2>
      <div className="card-grid">
        {imageModels.map((m) => (
          <a className="card" key={m.name} href={m.url} target="_blank" rel="noopener noreferrer">
            <span className="card-title">{m.name}</span>
            <span className="card-url">{m.url}</span>
          </a>
        ))}
      </div>
    </div>
  );
}