import React from "react";
const llms = [
  { name: "Qwen3 Series", url: "https://github.com/QwenLM/Qwen3" },
  { name: "DeepSeek", url: "https://github.com/deepseek-ai/deepseek-llm" },
  { name: "Kimi K2", url: "https://github.com/Moonshot-AI/kimi" },
  { name: "Wu Dao 3.0", url: "https://github.com/BAAI-LLM/WuDao" },
  { name: "ChatGLM", url: "https://github.com/THUDM/ChatGLM" },
];
export default function LLMPanel() {
  return (
    <div className="panel llms">
      <h2>LLMs (Large Language Models)</h2>
      <div className="card-grid">
        {llms.map((m) => (
          <a className="card" key={m.name} href={m.url} target="_blank" rel="noopener noreferrer">
            <span className="card-title">{m.name}</span>
            <span className="card-url">{m.url}</span>
          </a>
        ))}
      </div>
    </div>
  );
}