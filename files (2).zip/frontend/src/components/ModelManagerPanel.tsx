import React from "react";
const models = [
  { name: "Qwen3", status: "Installed" },
  { name: "DeepSeek", status: "Not Installed" },
  { name: "Seedream-3", status: "Installed" },
  { name: "Stable Diffusion", status: "Installed" },
];
export default function ModelManagerPanel() {
  return (
    <div className="panel model-manager">
      <h2>Model Manager</h2>
      <table style={{ width: "100%", background: "#23293a", borderRadius: "8px", color: "#fff" }}>
        <thead>
          <tr>
            <th>Model Name</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {models.map((model) => (
            <tr key={model.name}>
              <td>{model.name}</td>
              <td>{model.status}</td>
              <td>
                <button style={{ marginRight: "8px" }}>Install</button>
                <button>Run</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}