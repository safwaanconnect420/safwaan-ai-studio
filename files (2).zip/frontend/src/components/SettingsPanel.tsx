import React from "react";
export default function SettingsPanel() {
  return (
    <div className="panel settings">
      <h2>Settings</h2>
      <form>
        <label>
          Theme:
          <select>
            <option value="dark">Dark</option>
            <option value="light">Light</option>
          </select>
        </label>
        <label>
          API Key:
          <input type="password" placeholder="Enter API Key" />
        </label>
        <label>
          Backend Endpoint:
          <input type="url" placeholder="http://localhost:8000" />
        </label>
        <button type="submit">Save Settings</button>
      </form>
    </div>
  );
}