import React from "react";
import { FaTools, FaCubes, FaImages, FaVideo, FaRobot, FaPencilRuler, FaServer, FaCog } from "react-icons/fa";

const tabIcons: { [key: string]: React.ReactNode } = {
  "App Builders": <FaCubes />,
  "Dev Tools": <FaTools />,
  "Image Generation": <FaImages />,
  "Video Generation": <FaVideo />,
  "LLMs": <FaRobot />,
  "Sketch to 3D": <FaPencilRuler />,
  "Model Manager": <FaServer />,
  "Settings": <FaCog />,
};

export default function Sidebar({ tabs, selected, onSelect }: { tabs: string[]; selected: string; onSelect: (tab: string) => void }) {
  return (
    <aside className="sidebar">
      <h2>Safwaan AI Studio</h2>
      <nav>
        <ul className="tab-list">
          {tabs.map((tab) => (
            <li
              key={tab}
              className={selected === tab ? "active" : ""}
              title={tab}
              onClick={() => onSelect(tab)}
            >
              {tabIcons[tab]} <span>{tab}</span>
            </li>
          ))}
        </ul>
      </nav>
    </aside>
  );
}