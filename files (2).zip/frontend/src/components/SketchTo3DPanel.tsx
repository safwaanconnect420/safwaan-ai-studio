import React from "react";
export default function SketchTo3DPanel() {
  return (
    <div className="panel sketch-to-3d">
      <h2>Sketch to 3D Model</h2>
      <div style={{ padding: "2rem", border: "1px solid #23293a", borderRadius: "8px", background: "#23293a" }}>
        <p>Draw your sketch here, select an AI model, and convert to 3D!</p>
        {/* Integrate Konva.js/Fabric.js for sketch pad */}
        {/* Integrate Three.js for 3D model viewing */}
      </div>
    </div>
  );
}