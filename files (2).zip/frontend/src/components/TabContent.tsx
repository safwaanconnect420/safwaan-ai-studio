import React from "react";
import AppBuildersPanel from "./AppBuildersPanel";
import DevToolsPanel from "./DevToolsPanel";
import ImageGenPanel from "./ImageGenPanel";
import VideoGenPanel from "./VideoGenPanel";
import LLMPanel from "./LLMPanel";
import SketchTo3DPanel from "./SketchTo3DPanel";
import ModelManagerPanel from "./ModelManagerPanel";
import SettingsPanel from "./SettingsPanel";

export default function TabContent({ tab }: { tab: string }) {
  switch (tab) {
    case "App Builders":
      return <AppBuildersPanel />;
    case "Dev Tools":
      return <DevToolsPanel />;
    case "Image Generation":
      return <ImageGenPanel />;
    case "Video Generation":
      return <VideoGenPanel />;
    case "LLMs":
      return <LLMPanel />;
    case "Sketch to 3D":
      return <SketchTo3DPanel />;
    case "Model Manager":
      return <ModelManagerPanel />;
    case "Settings":
      return <SettingsPanel />;
    default:
      return <div>Select a tab.</div>;
  }
}