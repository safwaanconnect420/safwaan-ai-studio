import React from "react";
const videoModels = [
  { name: "Stable Video Diffusion", url: "https://github.com/Stability-AI/stable-video-diffusion" },
  { name: "Deforum", url: "https://github.com/deforum-art/deforum-stable-diffusion" },
  { name: "AnimateDiff", url: "https://github.com/guoyww/AnimateDiff" },
  { name: "Pix2Video", url: "https://github.com/Pix2Video/Pix2Video" },
  { name: "StepStar", url: "https://github.com/StepStarAI/StepStar" },
  { name: "Ming-Lite", url: "#" },
];
export default function VideoGenPanel() {
  return (
    <div className="panel video-gen">
      <h2>Video Generation Models</h2>
      <div className="card-grid">
        {videoModels.map((m) => (
          <a className="card" key={m.name} href={m.url} target="_blank" rel="noopener noreferrer">
            <span className="card-title">{m.name}</span>
            <span className="card-url">{m.url}</span>
          </a>
        ))}
      </div>
    </div>
  );
}